﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Drawing.Drawing2D;
using System.Drawing.Imaging;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public  class coordination
        {
            public coordination()
            {
                X_value = 50;
                Y_value = 50;
                X1_value = 50;
                Y1_value = 100;


            }
            private int x_value;
            public int X_value
            {
                get { return x_value; }
                set { x_value = value; }
            }
            private int y_value;
            public int Y_value
            {
                get { return y_value; }
                set { y_value = value; }
            }
            private int x1_value;
            public int X1_value
            {
                get { return x1_value; }
                set { x1_value = value; }
            }
            private int y1_value;
            public int Y1_value
            {
                get { return y1_value; }
                set { y1_value = value; }
            }
        }
        public Form1()
        {
            InitializeComponent();
        }
        public const int x=100;
         public const int  y=100;
         public const int l = 50;

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            Graphics pic = this.CreateGraphics();
            pic.Clear(Color.White);
            Pen pen_maliang = new System.Drawing.Pen(Color.Blue);
           // pic.DrawLine(pen_maliang, x, y, x + l * (int)(Math.Sin(Convert.ToSingle(textBox1.Text) / 180 * Math.PI)), y + l * (int)(Math.Cos((Convert.ToInt16(textBox1.Text) / 180) * Math.PI)));
            pic.DrawLine(pen_maliang, x, y, x + (int)(l * Math.Sin((hScrollBar1.Value) / 180f * Math.PI)), y + (int)(l * Math.Cos((hScrollBar1.Value) / 180f * Math.PI)));
            pic.DrawLine(pen_maliang, x, y, x + (int)(l * Math.Sin((hScrollBar1.Value) / 180f * Math.PI)), y);
            pic.DrawEllipse(pen_maliang,x-l,y-l,2*l,2*l);
            textBox3.Text = Convert.ToString(l * Math.Sin((hScrollBar1.Value) / 180f * Math.PI));
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox3.Text=Convert.ToString(Math.Sin(Convert.ToSingle(textBox2.Text)/180 * Math.PI));
        }

        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
            Graphics pic = this.CreateGraphics();
            pic.Clear(Color.White);
            Pen pen_maliang = new System.Drawing.Pen(Color.Blue);

            pic.DrawLine(pen_maliang, x, y  + (int)(hScrollBar2.Value), x+100, y  + (int)(hScrollBar2.Value));
        }

        private void hScrollBar3_Scroll(object sender, ScrollEventArgs e)
        {
            Graphics pic = this.CreateGraphics();
            pic.Clear(Color.White);
            Pen pen_maliang = new System.Drawing.Pen(Color.Blue);

            pic.DrawLine(pen_maliang, x + (int)(hScrollBar3.Value), y, x + (int)(hScrollBar3.Value), y + 100 + (int)(hScrollBar2.Value));
        }

        private void hScrollBar4_Scroll(object sender, ScrollEventArgs e)
        {
           
          
            xy.X_value += (int)(hScrollBar4.Value-5);
            xy.X1_value += (int)(hScrollBar4.Value - 5);
            Graphics pic = this.CreateGraphics();
            pic.Clear(Color.White);
            Pen pen_maliang = new System.Drawing.Pen(Color.Blue);

            pic.DrawLine(pen_maliang,xy.X_value,xy.Y_value,xy.X1_value,xy.Y1_value);
        }
        coordination xy = new coordination();
        private void hScrollBar5_Scroll(object sender, ScrollEventArgs e)
        {

            xy.Y_value += (int)(hScrollBar5.Value - 5);
            xy.Y1_value += (int)(hScrollBar5.Value - 5);
           
            Graphics pic = this.CreateGraphics();
            pic.Clear(Color.White);
            Pen pen_maliang = new System.Drawing.Pen(Color.Blue);

            pic.DrawLine(pen_maliang, xy.X_value, xy.Y_value, xy.X1_value, xy.Y1_value);
        }

        private void hScrollBar6_Scroll(object sender, ScrollEventArgs e)
        {
            xy.Y_value += (int)(hScrollBar5.Value - 5);
            xy.Y1_value += (int)(hScrollBar5.Value - 5);

            Graphics pic = this.CreateGraphics();
            pic.Clear(Color.White);
            Pen pen_maliang = new System.Drawing.Pen(Color.Blue);

            pic.DrawLine(pen_maliang, xy.X_value, xy.Y_value, xy.X1_value, xy.Y1_value);
        }
    }
}
